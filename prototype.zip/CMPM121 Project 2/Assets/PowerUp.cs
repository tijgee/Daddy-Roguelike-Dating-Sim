﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PowerUp : MonoBehaviour
{

    //public Text score;

    bool wasPickedUp = false;
    //int score_num = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        var transform = this.GetComponent<Transform>();
        transform.localRotation *= Quaternion.Euler(0.0f, 100.0f * Time.deltaTime, 0.0f);
        
        //if powerup was picked up
        if(this.wasPickedUp){
            //shrink powerup when destroying
            //transform.localScale *= 0.8f;
            this.wasPickedUp = false;
            
            //score_num += 1;
            
        }


        //this.GetComponent<Camera>().depth =...; //how you change camera's depth

        //keeping track of score/power up
        //this.score.text = "PowerUps: " + this.score_num.ToString();


    }

    //destroy powerup if collision occurs
    void OnTriggerEnter(Collider collider){
        if( collider.gameObject.CompareTag("Player")){
            //Debug.Log("yuh");
            Object.Destroy(this.gameObject);
            this.wasPickedUp = true;
        }
    }

    /*
    void OnTriggerExit(Collider collider){
        if( collider.gameObject.CompareTag("Player")){
            score_num += 1;
            Debug.Log("yuh");
        }

    }*/
}
