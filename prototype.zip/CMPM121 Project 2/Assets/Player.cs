﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public Text score;
    public float speed = 1.0f;

    // connecting camera to Player( allows you to drag first person camera to Player's script next to firstPerson)
    public Camera firstPerson;

    int score_num = 0;

    // Start is called before the first frame update
    void Start()
    {
        //set speed to 15
        speed = 10.0f;

        //get access to camera components
        //firstPerson = gameObject.GetComponent<Camera>;
        firstPerson.depth = 1.0f;
    }

    // Update is called once per frame
    void Update()
    {
        /*
        //manually adding charcter controllers
        var transform = this.GetComponent<Transform>();
        var position = transform.position;
        position.x += this.speed * Input.GetAxis("Horizontal")* Time.deltaTime;
        position.z += this.speed * Input.GetAxis("Vertical")* Time.deltaTime;
        transform.position = position;
        //Debug.Log(Input.GetAxis("Horizontal")); //tells us coordinates to horizontal controller
        */

        //using CharcterController
        var CharacterController = this.GetComponent<CharacterController>();
        CharacterController.SimpleMove(new Vector3(
            this.speed * Input.GetAxis("Horizontal"), 
            0.0f, 
            this.speed * Input.GetAxis("Vertical"))); //new vector3 (x,y,z)

        //raycasting
        var ray = new Ray( this.transform.position, new Vector3(0.0f,0.0f,1.0f)); //Ray(origin of ray, direction ray is hitting)
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit)){ // this returns a boolean
            Debug.Log(hit);
        }

        //keeping track of score/power up
        this.score.text = "PowerUps: " + this.score_num.ToString();

       
    }

    // add point to power up score
    void OnTriggerEnter(Collider collider){
        if( collider.gameObject.CompareTag("Powerups")){
            //Debug.Log("yuh");
            score_num += 1;
            
        }
    }

    // mkaes the fuction appear when setting up OnClick() for switch camera button
    public void switchCamera(){
        if(firstPerson.depth == 1.0f){
            //if in third person, switch to first person
            firstPerson.depth = 3.0f;
        }else{
            // if already in first then switch to third
            firstPerson.depth = 1.0f;
        }
    }
}
